#!/usr/bin/env python3
"""
Randomly access 50 webpages and extract main content.
"""

import random
import time
import requests
import sys
from urllib.parse import urljoin, urlparse
from bs4 import BeautifulSoup

# Set stdout encoding to UTF-8
sys.stdout.reconfigure(encoding='utf-8')

# List of popular websites to randomly sample from
POPULAR_WEBSITES = [
    "https://www.wikipedia.org",
    "https://www.reddit.com",
    "https://www.github.com",
    "https://www.stackoverflow.com",
    "https://www.medium.com",
    "https://www.bbc.com",
    "https://www.cnn.com",
    "https://www.nytimes.com",
    "https://www.theguardian.com",
    "https://www.techcrunch.com",
    "https://www.wired.com",
    "https://www.arstechnica.com",
    "https://www.theverge.com",
    "https://www.engadget.com",
    "https://www.lifehacker.com",
    "https://www.producthunt.com",
    "https://news.ycombinator.com",
    "https://www.bloomberg.com",
    "https://www.forbes.com",
    "https://www.huffpost.com",
    "https://www.buzzfeed.com",
    "https://www.vox.com",
    "https://www.slate.com",
    "https://www.salon.com",
    "https://www.politico.com",
    "https://www.reuters.com",
    "https://www.apnews.com",
    "https://www.npr.org",
    "https://www.pbs.org",
    "https://www.nationalgeographic.com",
    "https://www.smithsonianmag.com",
    "https://www.scientificamerican.com",
    "https://www.nature.com",
    "https://www.science.org",
    "https://www.economist.com",
    "https://www.hbr.org",
    "https://www.mit.edu",
    "https://www.stanford.edu",
    "https://www.harvard.edu",
    "https://www.berkeley.edu",
    "https://www.nasa.gov",
    "https://www.esa.int",
    "https://www.un.org",
    "https://www.worldbank.org",
    "https://www.imf.org",
    "https://www.who.int",
    "https://www.cdc.gov",
    "https://www.nih.gov",
    "https://www.mayoclinic.org",
    "https://www.webmd.com",
    "https://www.healthline.com",
    "https://www.medicalnewstoday.com",
    "https://www.verywellhealth.com",
    "https://www.psychologytoday.com",
    "https://www.mentalfloss.com",
    "https://www.howstuffworks.com",
    "https://www.wikihow.com",
    "https://www.instructables.com",
    "https://www.makeuseof.com",
    "https://www.digitaltrends.com",
    "https://www.cnet.com",
    "https://www.zdnet.com",
    "https://www.tomshardware.com",
    "https://www.anandtech.com",
    "https://www.pcgamer.com",
    "https://www.ign.com",
    "https://www.gamespot.com",
    "https://www.polygon.com",
    "https://www.kotaku.com",
    "https://www.rockpapershotgun.com",
    "https://www.eurogamer.net",
    "https://www.gamesradar.com",
    "https://www.pcgamingwiki.com",
    "https://www.gog.com",
    "https://store.steampowered.com",
    "https://www.epicgames.com",
    "https://www.unity.com",
    "https://www.unrealengine.com",
    "https://www.blender.org",
    "https://www.khanacademy.org",
    "https://www.coursera.org",
    "https://www.edx.org",
    "https://www.udemy.com",
    "https://www.skillshare.com",
    "https://www.linkedin.com/learning",
    "https://www.codecademy.com",
    "https://www.freecodecamp.org",
    "https://www.w3schools.com",
    "https://www.mozilla.org",
    "https://www.google.com",
    "https://www.apple.com",
    "https://www.microsoft.com",
    "https://www.amazon.com",
    "https://www.ebay.com",
    "https://www.etsy.com",
    "https://www.shopify.com",
    "https://www.squarespace.com",
    "https://www.wordpress.com",
    "https://www.tumblr.com",
    "https://www.pinterest.com",
    "https://www.instagram.com",
    "https://www.twitter.com",
    "https://www.facebook.com",
    "https://www.linkedin.com",
    "https://www.youtube.com",
    "https://www.tiktok.com",
    "https://www.snapchat.com",
    "https://www.whatsapp.com",
    "https://www.telegram.org",
    "https://www.discord.com",
    "https://www.slack.com",
    "https://www.zoom.us",
    "https://www.skype.com",
    "https://www.spotify.com",
    "https://www.soundcloud.com",
    "https://www.bandcamp.com",
    "https://www.last.fm",
    "https://www.shazam.com",
    "https://www.genius.com",
    "https://www.lyrics.com",
    "https://www.imdb.com",
    "https://www.rottentomatoes.com",
    "https://www.metacritic.com",
    "https://www.letterboxd.com",
    "https://www.goodreads.com",
    "https://www.librarything.com",
    "https://www.archive.org",
    "https://www.gutenberg.org",
    "https://www.jstor.org",
    "https://www.scholar.google.com",
    "https://www.researchgate.net",
    "https://www.academia.edu",
    "https://www.semanticscholar.org",
    "https://www.patents.google.com",
    "https://www.uspto.gov",
    "https://www.loc.gov",
    "https://www.britishmuseum.org",
    "https://www.metmuseum.org",
    "https://www.louvre.fr",
    "https://www.uffizi.it",
    "https://www.vatican.va",
    "https://www.nga.gov",
    "https://www.moma.org",
    "https://www.tate.org.uk",
    "https://www.guggenheim.org",
    "https://www.whitney.org",
    "https://www.newmuseum.org",
    "https://www.cooperhewitt.org",
    "https://www.aaa.si.edu",
    "https://www.aaa.org",
    "https://www.aam-us.org",
    "https://www.icom.museum",
    "https://www.unesco.org",
    "https://www.iccrom.org",
    "https://www.getty.edu",
    "https://www.nga.gov",
    "https://www.arts.gov",
    "https://www.neh.gov",
    "https://www.imls.gov",
    "https://www.archives.gov",
    "https://www.preservationnation.org",
    "https://www.nationaltrust.org",
    "https://www.english-heritage.org.uk",
    "https://www.historicengland.org.uk",
    "https://www.cadw.gov.wales",
    "https://www.historicenvironment.scot",
    "https://www.heritageireland.ie",
    "https://www.europa-nostra.org",
    "https://www.into.org",
    "https://www.worldmonuments.org",
    "https://www.globalheritagefund.org",
    "https://www.savingantiquities.org",
    "https://www.archaeological.org",
    "https://www.saa.org",
    "https://www.ajaonline.org",
    "https://www.jstor.org/stable",
    "https://www.cambridge.org",
    "https://www.oxfordhandbooks.com",
    "https://www.routledge.com",
    "https://www.sagepub.com",
    "https://www.springer.com",
    "https://www.wiley.com",
    "https://www.elsevier.com",
    "https://www.tandfonline.com",
    "https://www.degruyter.com",
    "https://www.brill.com",
    "https://www.projectmuse.org",
    "https://www.ingentaconnect.com",
    "https://www.doaj.org",
    "https://www.crossref.org",
    "https://www.orcid.org",
    "https://www.zotero.org",
    "https://www.mendeley.com",
    "https://www.endnote.com",
    "https://www.refworks.com",
    "https://www.easybib.com",
    "https://www.citationmachine.net",
    "https://www.bibme.org",
    "https://www.citefast.com",
    "https://www.noodletools.com",
    "https://www.noted.org",
    "https://www.evernote.com",
    "https://www.onenote.com",
    "https://www.notion.so",
    "https://www.roamresearch.com",
    "https://www.obsidian.md",
    "https://www.logseq.com",
    "https://www.remnote.com",
    "https://www.ankiweb.net",
    "https://www.quizlet.com",
    "https://www.studyblue.com",
    "https://www.chegg.com",
    "https://www.coursehero.com",
    "https://www.sparknotes.com",
    "https://www.cliffsnotes.com",
    "https://www.bartleby.com",
    "https://www.enotes.com",
    "https://www.gradesaver.com",
    "https://www.litcharts.com",
    "https://www.shmoop.com",
    "https://www.novelguide.com",
    "https://www.bookrags.com",
    "https://www.123helpme.com",
    "https://www.papercamp.com",
    "https://www.exampleessays.com",
    "https://www.essaydepot.com",
    "https://www.antiessays.com",
    "https://www.directessays.com",
    "https://www.megaessays.com",
    "https://www.reviewessays.com",
    "https://www.essayworld.com",
    "https://www.essaytown.com",
    "https://www.termpaperwarehouse.com",
    "https://www.academon.com",
    "https://www.paperdue.com",
    "https://www.writing.com",
    "https://www.writersdigest.com",
    "https://www.poets.org",
    "https://www.poetryfoundation.org",
    "https://www.poetrydaily.org",
    "https://www.versedaily.org",
    "https://www.fictionaut.com",
    "https://www.duotrope.com",
    "https://www.submittable.com",
    "https://www.chillsubs.com",
    "https://www.newpages.com",
    "https://www.pw.org",
    "https://www.literaryhub.com",
    "https://www.lithub.com",
    "https://www.bookriot.com",
    "https://www.electricliterature.com",
    "https://www.catapult.co",
    "https://www.guernicamag.com",
    "https://www.tinhouse.com",
    "https://www.granta.com",
    "https://www.parisreview.org",
    "https://www.nybooks.com",
    "https://www.lrb.co.uk",
    "https://www.harpers.org",
    "https://www.theatlantic.com",
    "https://www.newyorker.com",
    "https://www.vanityfair.com",
    "https://www.rollingstone.com",
    "https://www.esquire.com",
    "https://www.gq.com",
    "https://www.menshealth.com",
    "https://www.womenshealthmag.com",
    "https://www.self.com",
    "https://www.shape.com",
    "https://www.fitnessmagazine.com",
    "https://www.runnersworld.com",
    "https://www.bicycling.com",
    "https://www.outsideonline.com",
    "https://www.backpacker.com",
    "https://www.climbing.com",
    "https://www.surfer.com",
    "https://www.skimag.com",
    "https://www.powder.com",
    "https://www.transworld.net",
    "https://www.thrashermagazine.com",
    "https://www.snowboarder.com",
    "https://www.freeskier.com",
    "https://www.tetongravity.com",
    "https://www.newschoolers.com",
    "https://www.fis-ski.com",
    "https://www.worldathletics.org",
    "https://www.worldaquatics.com",
    "https://www.fifa.com",
    "https://www.uefa.com",
    "https://www.nba.com",
    "https://www.nfl.com",
    "https://www.mlb.com",
    "https://www.nhl.com",
    "https://www.pgatour.com",
    "https://www.atptour.com",
    "https://www.wtatennis.com",
    "https://www.itftennis.com",
    "https://www.rolandgarros.com",
    "https://www.wimbledon.com",
    "https://www.usopen.org",
    "https://www.ausopen.com",
    "https://www.icc-cricket.com",
    "https://www.espncricinfo.com",
    "https://www.rugbyworldcup.com",
    "https://www.world.rugby",
    "https://www.espn.com",
    "https://www.sports.yahoo.com",
    "https://www.cbssports.com",
    "https://www.foxsports.com",
    "https://www.nbcsports.com",
    "https://www.si.com",
    "https://www.bleacherreport.com",
    "https://www.sbnation.com",
    "https://www.deadspin.com",
    "https://www.thebiglead.com",
    "https://www.barstoolsports.com",
    "https://www.outkick.com",
    "https://www.clutchpoints.com",
    "https://www.fansided.com",
    "https://www.sportingnews.com",
    "https://www.goal.com",
    "https://www.transfermarkt.com",
    "https://www.whoscored.com",
    "https://www.sofascore.com",
    "https://www.flashscore.com",
    "https://www.livescore.com",
    "https://www.soccerway.com",
    "https://www.worldfootball.net",
    "https://www.national-football-teams.com",
    "https://www.11v11.com",
    "https://www.transfermarkt.us",
    "https://www.besoccer.com",
    "https://www.fotmob.com",
    "https://www.onefootball.com",
    "https://www.footballdatabase.eu",
    "https://www.playmakerstats.com",
    "https://www.zerozero.pt",
    "https://www.resultados.com",
    "https://www.tuttosport.com",
    "https://www.gazzetta.it",
    "https://www.corrieredellosport.it",
    "https://www.as.com",
    "https://www.marca.com",
    "https://www.mundodeportivo.com",
    "https://www.sport.es",
    "https://www.lequipe.fr",
    "https://www.lemonde.fr",
    "https://www.lefigaro.fr",
    "https://www.liberation.fr",
    "https://www.faz.net",
    "https://www.spiegel.de",
    "https://www.zeit.de",
    "https://www.sueddeutsche.de",
    "https://www.welt.de",
    "https://www.nzz.ch",
    "https://www.tagesanzeiger.ch",
    "https://www.20min.ch",
    "https://www.corriere.it",
    "https://www.repubblica.it",
    "https://www.lastampa.it",
    "https://www.ilsole24ore.com",
    "https://www.elpais.com",
    "https://www.elmundo.es",
    "https://www.abc.es",
    "https://www.lavanguardia.com",
    "https://www.rtve.es",
    "https://www.bbc.co.uk",
    "https://www.itv.com",
    "https://www.channel4.com",
    "https://www.channel5.com",
    "https://www.sky.com",
    "https://www.bt.com",
    "https://www.virginmedia.com",
    "https://www.freeview.co.uk",
    "https://www.freesat.co.uk",
    "https://www.tvcatchup.com",
    "https://www.iplayer.com",
    "https://www.netflix.com",
    "https://www.hulu.com",
    "https://www.disneyplus.com",
    "https://www.hbomax.com",
    "https://www.amazon.com/primevideo",
    "https://www.peacocktv.com",
    "https://www.paramountplus.com",
    "https://www.apple.com/tv",
    "https://www.youtube.com/tv",
    "https://www.sling.com",
    "https://www.fubo.tv",
    "https://www.philo.com",
    "https://www.directv.com",
    "https://www.xfinity.com",
    "https://www.verizon.com",
    "https://www.att.com",
    "https://www.t-mobile.com",
    "https://www.sprint.com",
    "https://www.cricketwireless.com",
    "https://www.boost.com",
    "https://www.metropcs.com",
    "https://www.tracfone.com",
    "https://www.straighttalk.com",
    "https://www.mintmobile.com",
    "https://www.visible.com",
    "https://www.usmobile.com",
    "https://www.googlefi.com",
    "https://www.republicwireless.com",
    "https://www.ting.com",
    "https://www.consumer cellular.com",
    "https://www.greatcall.com",
    "https://www.jitterbug.com",
    "https://www.lively.com",
    "https://www.onstar.com",
    "https://www.siriusxm.com",
    "https://www.pandora.com",
    "https://www.iheart.com",
    "https://www.audacy.com",
    "https://www.tunein.com",
    "https://www.stitcher.com",
    "https://www.podcastaddict.com",
    "https://www.overcast.fm",
    "https://www.pocketcasts.com",
    "https://www.castro.fm",
    "https://www.downcastapp.com",
    "https://www.breaker.audio",
    "https://www.radiopublic.com",
    "https://www.castbox.fm",
    "https://www.stitcher.com",
    "https://www.audible.com",
    "https://www.scribd.com",
    "https://www.kindle.com",
    "https://www.kobo.com",
    "https://www.barnesandnoble.com",
    "https://www.booksamillion.com",
    "https://www.powells.com",
    "https://www.strandbooks.com",
    "https://www.citylights.com",
    "https://www.skylightbooks.com",
    "https://www.vromansbookstore.com",
    "https://www.tatteredcover.com",
    "https://www.bookpeople.com",
    "https://www.brazosbookstore.com",
    "https://www.bluewillowbookshop.com",
    "https://www.interabangbooks.com",
    "https://www.leftbankbooks.com",
    "https://www.parnassusbooks.net",
    "https://www.narnia.com",
    "https://www.raptureinvenice.com",
    "https://www.mcnallyjackson.com",
    "https://www.greenlightbookstore.com",
    "https://www.booksaremagic.net",
    "https://www.wordbookstores.com",
    "https://www.communitybookstore.net",
    "https://www.bookcourt.com",
    "https://www.powerhousearena.com",
    "https://www.desertbook.net",
    "https://www.bookshowla.com",
    "https://www.thelastbookstore.com",
    "https://www.cookbookla.com",
    "https://www.mystery-book.com",
    "https://www.samwellerbooks.com",
    "https://www.kingsenglish.com",
    "https://www.wellerbookworks.com",
    "https://www.squarebooks.com",
    "https://www.turnrowbooks.com",
    "https://www.lemuriabooks.com",
    "https://www.octaviabooks.com",
    "https://www.gardendistrictbookshop.com",
    "https://www.maplestreetbookshop.com",
    "https://www.wildrumpusbooks.com",
    "https://www.magersandquinn.com",
    "https://www.nextchapterbooksellers.com",
    "https://www.commongoodbooks.com",
    "https://www.redballoonbookshop.com",
    "https://www.subtextbooks.com",
    "https://www.unicornbooks.com",
    "https://www.birchbarkbooks.com",
    "https://www.moonpalacebooks.com",
    "https://www.onceuponatimebooks.com",
]

def extract_main_content(html, url):
    """Extract main content from HTML."""
    soup = BeautifulSoup(html, 'html.parser')

    # Remove script and style elements
    for script in soup(["script", "style", "nav", "footer", "header", "aside"]):
        script.decompose()

    # Try to find main content area
    main_content = None

    # Look for common content containers
    for selector in ['main', 'article', '[role="main"]', '.content', '.main-content',
                     '#content', '#main-content', '.post-content', '.entry-content',
                     '.article-content', '.story-body']:
        main_content = soup.select_one(selector)
        if main_content:
            break

    # If no main content found, use body
    if not main_content:
        main_content = soup.find('body')

    if not main_content:
        return "No content found"

    # Get text and clean it up
    text = main_content.get_text(separator='\n', strip=True)

    # Clean up whitespace
    lines = [line.strip() for line in text.split('\n') if line.strip()]
    text = '\n'.join(lines)

    # Limit length
    if len(text) > 3000:
        text = text[:3000] + "..."

    return text

def fetch_and_extract(url, timeout=10):
    """Fetch a webpage and extract its main content."""
    try:
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
        }
        response = requests.get(url, headers=headers, timeout=timeout, allow_redirects=True)
        response.raise_for_status()

        content = extract_main_content(response.text, url)
        title_tag = BeautifulSoup(response.text, 'html.parser').find('title')
        title = title_tag.get_text(strip=True) if title_tag else 'No title'

        return {
            'url': response.url,
            'status': response.status_code,
            'title': title,
            'content': content
        }
    except requests.exceptions.Timeout:
        return {'url': url, 'status': 'Timeout', 'title': 'N/A', 'content': 'Request timed out'}
    except requests.exceptions.ConnectionError:
        return {'url': url, 'status': 'Connection Error', 'title': 'N/A', 'content': 'Could not connect to server'}
    except requests.exceptions.HTTPError as e:
        return {'url': url, 'status': f'HTTP Error: {e.response.status_code}', 'title': 'N/A', 'content': f'HTTP error occurred'}
    except Exception as e:
        return {'url': url, 'status': f'Error: {type(e).__name__}', 'title': 'N/A', 'content': str(e)}

def safe_print(text, output_file=None):
    """Safely print text, handling encoding issues."""
    try:
        print(text)
    except UnicodeEncodeError:
        # Try to encode and decode with replacement
        print(text.encode('utf-8', errors='replace').decode('utf-8', errors='replace'))

    if output_file:
        output_file.write(text + '\n')

def main():
    # Randomly select 50 URLs
    selected_urls = random.sample(POPULAR_WEBSITES, min(50, len(POPULAR_WEBSITES)))

    output_filename = 'webpage_results.txt'

    with open(output_filename, 'w', encoding='utf-8') as output_file:
        def write_line(text):
            safe_print(text, output_file)

        write_line("=" * 80)
        write_line("RANDOM WEBPAGE CONTENT EXTRACTOR")
        write_line("=" * 80)
        write_line(f"\nRandomly selected {len(selected_urls)} websites to visit:\n")

        results = []

        for i, url in enumerate(selected_urls, 1):
            write_line(f"\n{'='*80}")
            write_line(f"[{i}/50] Accessing: {url}")
            write_line('='*80)

            result = fetch_and_extract(url)
            results.append(result)

            write_line(f"Status: {result['status']}")
            write_line(f"Title: {result['title']}")
            write_line(f"\n--- Main Content ---")
            content_preview = result['content'][:2000] if len(result['content']) > 2000 else result['content']
            write_line(content_preview)
            if len(result['content']) > 2000:
                write_line("...")

            # Small delay to be respectful
            if i < len(selected_urls):
                time.sleep(0.5)

        # Summary
        write_line("\n" + "=" * 80)
        write_line("SUMMARY")
        write_line("=" * 80)

        successful = sum(1 for r in results if isinstance(r['status'], int) and r['status'] == 200)
        write_line(f"Total websites attempted: {len(results)}")
        write_line(f"Successful requests: {successful}")
        write_line(f"Failed requests: {len(results) - successful}")

        write_line("\n" + "=" * 80)
        write_line("ALL RESULTS")
        write_line("=" * 80)

        for i, result in enumerate(results, 1):
            write_line(f"\n[{i}] {result['url']}")
            write_line(f"    Status: {result['status']}")
            write_line(f"    Title: {result['title']}")
            write_line(f"    Content Preview: {result['content'][:200]}...")

    print(f"\n\nResults saved to: {output_filename}")

if __name__ == "__main__":
    main()
